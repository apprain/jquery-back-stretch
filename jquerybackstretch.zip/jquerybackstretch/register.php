<?php
/**
 * appRain CMF
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Inc. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */

/**
 * Developed by: Reazaul Karim
 *
 * Created a slide show specailly for whitecloud theme
 */
class Component_JQueryBackStretch_Register extends appRain_Base_Component
{
    /**
     * Initialize the basic
     * Resource on load
     */
    public function init()
    {
 
        App::Module('Hook')
            ->setHookName('Javascript')
            ->setAction("register_javascript_code")
            ->Register(get_class($this),"register_javascript_code");

        App::Module('Hook')
            ->setHookName('UI')
            ->setAction("home_page_banner")
            ->Register(get_class($this),"add_html");

        
        App::Module('Hook')
            ->setHookName('InterfaceBuilder')
            ->setAction("update_definition")
            ->Register(get_class($this),"interfacebuilder_update_definition");

        App::Module('Hook')
            ->setHookName('InformationSet')
            ->setAction("register_definition")
            ->Register(get_class($this),"register_informationset_defination");

		App::Module('Hook')
            ->setHookName('Sitesettings')
            ->setAction("register_definition")
            ->Register(get_class($this), "register_sitesettings_defination");					
    }

    public function init_on_install(){}

    public function init_on_uninstall(){}

     public function register_javascript_code()
    {
        return App::Helper('Utility')->fetchFile($this->attachMyPath('js/jquery.backstretch.js'));
    }

    public function add_html($send)
    {
        $pressdata = App::InformationSet('jquerybackstretch')->findAll("status='Active' ORDER BY sortorder ASC");
        return App::Helper('Utility')->callElementByPath($this->attachMyPath('elements/addhtml.phtml'),array('pressdata'=>$pressdata));
    }

    public function interfacebuilder_update_definition($send)
    {
        if(isset($send['component']['child']))
        {
            $send['component']['child'][] = Array(
                "title"=>"jQuery Back Stretch",
                "items"=>Array(
					array(
                        "title"=>"Preference",
                        "link"=>"/admin/config/jquerybackstretch"
                    ),
                    array(
                        "title"=>"New Slide",
                        "link"=>"/information/manage/jquerybackstretch/add"
                    ),
                    array(
                        "title"=>"Manage Slides",
                        "link"=>"/information/manage/jquerybackstretch")
                    ),
                    "adminicon" => array("type"=>"filePath",'location'=>'/component/jquerybackstretch/icon/logo.jpg'));
            return $send;
        }
    }

    public function register_informationset_defination()
    {
        $srcpaths = Array();
        $srcpaths[] = array(
            'type'=>'jquerybackstretch',
            'path'=>$this->attachMyPath('information_set/jquerybackstretch.xml')
        );
        return $srcpaths;
    }
	
    public function register_sitesettings_defination()
    {
        $srcpaths = Array();
        $srcpaths[] = $this->attachMyPath('sitesettings/settings.xml');

        return array(
            'filepaths' => $srcpaths
        );
    }	
}